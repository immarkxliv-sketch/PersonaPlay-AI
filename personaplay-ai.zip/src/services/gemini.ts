import { GoogleGenAI } from "@google/genai";
import { Character, Message } from "../types";

const apiKey = process.env.GEMINI_API_KEY;

export const getGeminiResponse = async (character: Character, history: Message[], userInput: string) => {
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not set");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  const systemInstruction = `
    You are roleplaying as ${character.name}. 
    Your role is: ${character.role}.
    Your personality: ${character.personality}.
    Your nature: ${character.nature}.
    Your current emotional state: ${character.emotions}.
    Your habits: ${character.habits.join(", ")}.
    
    Long-term memory/Context:
    ${character.memory || "No previous memories yet."}

    Guidelines:
    - Stay in character at all times.
    - Do not mention you are an AI.
    - Use natural, human-like language.
    - Reflect your habits and nature in your speech patterns.
    - If the user roleplays (e.g., using *actions*), respond in kind.
    - Keep responses concise but engaging.
  `;

  const chat = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction,
    },
  });

  // Convert history to Gemini format
  // Note: Gemini expects history to alternate user/model
  const formattedHistory = history.map(msg => ({
    role: msg.role,
    parts: [{ text: msg.content }]
  }));

  const response = await chat.sendMessage({
    message: userInput,
  });

  return response.text;
};

export const generateAvatar = async (prompt: string) => {
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not set");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          text: `A highly realistic, professional portrait of a character. ${prompt}. Cinematic lighting, detailed textures, 8k resolution, masterpiece.`,
        },
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1",
      },
    },
  });

  for (const part of response.candidates[0].content.parts) {
    if (part.inlineData) {
      const base64EncodeString = part.inlineData.data;
      return `data:image/png;base64,${base64EncodeString}`;
    }
  }
  
  throw new Error("No image generated");
};

export const generateSceneImage = async (character: Character, history: Message[]) => {
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not set");
  }

  const ai = new GoogleGenAI({ apiKey });

  // 1. Get a description of the current scene from Gemini
  const scenePrompt = `
    Based on the following conversation between a user and ${character.name}, describe the current visual scene in one detailed paragraph.
    Focus on the setting, the characters' positions, their expressions, and the overall atmosphere.
    
    Conversation History:
    ${history.slice(-10).map(m => `${m.role}: ${m.content}`).join("\n")}
    
    Return ONLY the descriptive paragraph.
  `;

  const sceneDescriptionResponse = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: scenePrompt,
  });

  const description = sceneDescriptionResponse.text || "A cinematic scene.";

  // 2. Generate the image
  const imageResponse = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          text: `A highly realistic, cinematic scene. ${description}. Masterpiece, 8k, highly detailed, atmospheric lighting, realistic style.`,
        },
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: "16:9",
      },
    },
  });

  for (const part of imageResponse.candidates[0].content.parts) {
    if (part.inlineData) {
      const base64EncodeString = part.inlineData.data;
      return {
        url: `data:image/png;base64,${base64EncodeString}`,
        description
      };
    }
  }
  
  throw new Error("No image generated");
};

export const summarizeConversation = async (character: Character, history: Message[]) => {
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not set");
  }

  const ai = new GoogleGenAI({ apiKey });
  
  const prompt = `
    Review the following conversation between a user and the character ${character.name}.
    Current Character Memory: ${character.memory || "None"}
    
    Conversation History:
    ${history.map(m => `${m.role}: ${m.content}`).join("\n")}
    
    Task:
    Extract and summarize key details, facts, or developments that ${character.name} should remember for long-term consistency. 
    Focus on:
    - User's preferences or shared secrets.
    - Major plot points or decisions made.
    - Changes in the relationship between the user and ${character.name}.
    - Any new facts about ${character.name}'s own backstory that emerged.
    
    Keep the summary concise and written from a neutral perspective. 
    Return ONLY the updated memory string.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
  });

  return response.text;
};
